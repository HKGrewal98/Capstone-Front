import React from 'react'

export const Financials = () => {
  return (
    <div>Financials</div>
  )
}
