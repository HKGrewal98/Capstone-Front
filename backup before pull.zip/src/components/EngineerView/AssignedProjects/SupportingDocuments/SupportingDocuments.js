import React from 'react'
import Classes from './SupportingDocuments.module.css'

export const SupportingDocuments = () => {
  return (
    <div className={Classes.container}>SupportingDocuments</div>
  )
}
