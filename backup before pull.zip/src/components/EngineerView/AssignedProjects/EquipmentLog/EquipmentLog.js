import React from 'react'

export const EquipmentLog = () => {
  return (
    <div>EquipmentLog</div>
  )
}
