import React from 'react'

export const Details = () => {
  return (
    <div>Details</div>
  )
}
