import React from 'react'

export const SupportingDocuments = () => {
  return (
    <div>SupportingDocuments</div>
  )
}
