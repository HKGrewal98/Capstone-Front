import React from 'react'

export const Correspondence = () => {
  return (
    <div>Correspondence</div>
  )
}
