import React from 'react'

export const SideNav = () => {
  return (
    <div className='SideNavContainer'>
        
    </div>
  )
}
