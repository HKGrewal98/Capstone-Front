import React from "react";

export const UserDetailsContainer = () => {
  return (
    <table className="table table-striped">
     
        <thead>
          <tr>
            <th scope="col">UserName</th>
            <th scope="col">LastLogin</th>
            <th scope="col">Linked Accounts</th>
            <th scope="col">Status</th>
            <th scope="col">View</th>
            <th scope="col">View</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>User1</td>
            <td></td>
            <td>XYZ</td>
            <td></td>
            <td>Active</td>
            <td>VIew</td>
          </tr>
          <tr>
            <td>User1</td>
            <td></td>
            <td>XYZ</td>
            <td></td>
            <td>Active</td>
            <td>VIew</td>
          </tr>
          <tr>
            <td>User1</td>
            <td></td>
            <td>XYZ</td>
            <td></td>
            <td>Active</td>
            <td>VIew</td>
          </tr>
        </tbody>
      </table>
  );
};
