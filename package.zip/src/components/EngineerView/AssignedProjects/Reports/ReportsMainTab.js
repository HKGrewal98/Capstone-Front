import React from 'react'
import { Link } from 'react-router-dom'

export const ReportsMainTab = () => {
  return (
    <>
    <h1>ReportsMainTab</h1>
   
    </>
  )
}
