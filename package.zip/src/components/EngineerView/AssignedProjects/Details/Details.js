import React from 'react'

export const Details = () => {
  return (
    <div>
      
      <div className='Adddocument'>
      <button>ADD DOCUMENT </button>   
       
      </div>
      
      
     
      <table className="table">
        <tbody>
        <tr>
      <th scope="col">Project Name</th>
      <input type="Text" placeholder="Daily Compliance" required></input>
    
    </tr>

 
    <tr>
      <th scope="col">Project Description   <input type="Text" placeholder="Daily Compliance" required></input>
      </th>

      
    </tr>
    <tr>
      <th scope="col">Project Number</th>
      
    </tr>

    <tr>
      <th scope="col">Products Covered</th>
      
    </tr>

    <tr>
      <th scope="col">Models</th>
      
    </tr>
    <tr>
      <th scope="col">Assigned To</th>
      
    </tr>
    <tr>
      <th scope="col">Customers Name</th>
      
    </tr>
    <tr>
      <th scope="col">Client Recipient</th>
      
    </tr>
    <tr>
      <th scope="col">Start Date</th>
      
    </tr>
    <tr>
      <th scope="col">End Date</th>
      
    </tr>
    <tr>
      <th scope="col">Project Completion Date</th>
      
    </tr>

    <tr>
      <th scope="col">Reviewer</th>
      
    </tr>

    <tr>
      <th scope="col">BU (Business Unit)</th>
      
    </tr>

    <tr>
      <th scope="col">Quote Number</th>
      
    </tr>
    <tr>
      <th scope="col">PO Number</th>
      
    </tr>


  </tbody>
</table>
</div>
)
}
