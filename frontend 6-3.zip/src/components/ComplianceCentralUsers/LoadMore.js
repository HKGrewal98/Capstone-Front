import React from 'react'

export const LoadMore = () => {
  return (
    <div className='lmcontainer text-center'>
    <button className="AddUserBtn ">Load More</button>
    </div>
  )
}
