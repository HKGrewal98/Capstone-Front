import React from 'react'

export const Sample = () => {
  return (
    <div>Sample</div>
  )
}
